-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2017 at 01:01 PM
-- Server version: 5.5.50-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pset7`
--

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `action` varchar(10) NOT NULL,
  `shares` int(10) NOT NULL,
  `price` double NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `user_id`, `symbol`, `name`, `action`, `shares`, `price`, `date`) VALUES
(1, 0, '', 'SandRidge Energy, Inc. Common S', 'Buy', 3, 17, '2017-03-24 00:00:00'),
(5, 24, 'SD', 'SandRidge Energy, Inc. Common S', 'Buy', 12, 17.36, '2017-03-24 00:00:00'),
(6, 24, 'SR', 'Spire Inc. Common Stock', 'Buy', 1, 67.35, '2017-03-24 00:00:00'),
(7, 24, 'SD', 'SandRidge Energy, Inc. Common S', 'SELL', 67, 17.36, '2017-03-24 00:00:00'),
(8, 24, 'SD', 'SandRidge Energy, Inc.', 'Buy', 12, 17.335, '2017-03-24 00:00:00'),
(9, 24, 'SD', 'SandRidge Energy, Inc.', 'SELL', 12, 17.335, '2017-03-24 00:00:00'),
(10, 24, 'SD', 'SandRidge Energy, Inc.', 'Buy', 3, 17.36, '2017-03-24 15:19:32');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE IF NOT EXISTS `portfolio` (
  `user_id` int(10) unsigned NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `shares` int(10) NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`user_id`,`symbol`),
  UNIQUE KEY `user_id` (`user_id`,`symbol`),
  UNIQUE KEY `user_id_2` (`user_id`,`symbol`),
  UNIQUE KEY `user_id_3` (`user_id`,`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`user_id`, `symbol`, `shares`, `price`) VALUES
(24, 'FREE', 23, 1.15),
(24, 'SD', 3, 17.36),
(24, 'SR', 104, 67.35);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `cash` decimal(65,4) unsigned NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `hash`, `cash`) VALUES
(1, 'andi', '$2y$10$c.e4DK7pVyLT.stmHxgAleWq4yViMmkwKz3x8XCo4b/u3r8g5OTnS', 10000.0000),
(2, 'caesar', '$2y$10$0p2dlmu6HnhzEMf9UaUIfuaQP7tFVDMxgFcVs0irhGqhOxt6hJFaa', 10000.0000),
(3, 'eli', '$2y$10$COO6EnTVrCPCEddZyWeEJeH9qPCwPkCS0jJpusNiru.XpRN6Jf7HW', 10000.0000),
(4, 'hdan', '$2y$10$o9a4ZoHqVkVHSno6j.k34.wC.qzgeQTBHiwa3rpnLq7j2PlPJHo1G', 10000.0000),
(5, 'jason', '$2y$10$ci2zwcWLJmSSqyhCnHKUF.AjoysFMvlIb1w4zfmCS7/WaOrmBnLNe', 10000.0000),
(6, 'john', '$2y$10$dy.LVhWgoxIQHAgfCStWietGdJCPjnNrxKNRs5twGcMrQvAPPIxSy', 10000.0000),
(7, 'levatich', '$2y$10$fBfk7L/QFiplffZdo6etM.096pt4Oyz2imLSp5s8HUAykdLXaz6MK', 10000.0000),
(8, 'rob', '$2y$10$3pRWcBbGdAdzdDiVVybKSeFq6C50g80zyPRAxcsh2t5UnwAkG.I.2', 10000.0000),
(9, 'skroob', '$2y$10$395b7wODm.o2N7W5UZSXXuXwrC0OtFB17w4VjPnCIn/nvv9e4XUQK', 10000.0000),
(10, 'zamyla', '$2y$10$UOaRF0LGOaeHG4oaEkfO4O7vfI34B1W23WqHr9zCpXL68hfQsS3/e', 10000.0000),
(24, 'n', '$1$ngUpEzU4$wijgATdJiWLidayGQMvkl.', 4512.3800),
(25, 'y', '$2y$10$IFAgAV3nj5AsphWAHOf6lOmYhMWtHUhiICTHNMp/ynw2Pk6odRMO.', 10000.0000),
(26, '', '$2y$10$8CCBKq6P6PvH7eVqBSEyM.9NTpT2JVcsGLVRTyiugrZOwZcc7UAeG', 10000.0000),
(28, 'c', '$2y$10$2xq8ld2.10Rrfl/wOEcxVeslWMRf.27DhbZTU2OPHCPAlPYqgOAce', 10000.0000);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD CONSTRAINT `r1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
