
<form action="reset.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="old_password" placeholder="Current password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="new_password" placeholder="New password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="confirmation" placeholder="Re-enter Password" type="password"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Reset password</button>
        </div>
    </fieldset>
</form>