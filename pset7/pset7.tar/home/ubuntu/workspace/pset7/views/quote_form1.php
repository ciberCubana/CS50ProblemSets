<html>
<body text="green" bgcolor="white">
<pre>
<strong>The stock price for <?=$name?>(<?=$symbol?>) is $<?=number_format($price, 2)?></strong>
</strong>
</pre>
</body>
</html>

